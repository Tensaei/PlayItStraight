import numpy
import torch
import src.support as support

from src.support import clprint, Reason, get_time_in_millis


class SimpleActiveLearner:

    def __init__(self, dataset, al_technique, early_stopping_threshold):
        self.dataset = dataset
        self.al_technique = al_technique
        self.early_stopping_threshold = early_stopping_threshold
        self.n_samples_to_select = -1

    def elaborate(self, model, al_epochs, training_epochs, n_samples_to_select, criterion, optimizer):
        self.n_samples_to_select = n_samples_to_select
        clprint("Starting Active Learning process...", Reason.INFO_TRAINING)
        self._train_model(criterion, model, optimizer, training_epochs)
        for i in range(al_epochs):
            clprint("Making n.{}/{} AL epochs...".format(i + 1, al_epochs), Reason.INFO_TRAINING, loggable=True)
            clprint("Selecting {} new samples...".format(self.n_samples_to_select), Reason.INFO_TRAINING)
            start_time = get_time_in_millis()
            self._select_next_samples(self.n_samples_to_select)
            end_time = get_time_in_millis()
            clprint("Elapsed time: {}".format(end_time - start_time), Reason.LIGHT_INFO_TRAINING, loggable=True)
            accuracy = self._train_model(criterion, model, optimizer, training_epochs)
            if accuracy >= self.early_stopping_threshold:
                clprint("Early stopping due the accuracy threshold reached {}/{}".format(accuracy, self.early_stopping_threshold), Reason.INFO_TRAINING, loggable=True)
                break

    def _train_model(self, criterion, model, optimizer, training_epochs):
        clprint("Training model...", Reason.INFO_TRAINING)
        model.fit(training_epochs, criterion, optimizer, self.dataset.get_train_loader())
        clprint("Evaluating model...", Reason.INFO_TRAINING)
        loss, accuracy = model.evaluate(criterion, self.dataset.get_test_loader())
        clprint("Loss: {}\nAccuracy: {}".format(loss, accuracy), Reason.LIGHT_INFO_TRAINING, loggable=True)
        return accuracy

    def _select_next_samples(self, n_samples_to_select):
        xs = self.al_technique.select_samples(self.dataset.get_unselected_data(), n_samples_to_select)
        self.dataset.annotate(xs)
        clprint("Updating AL technique...".format(self.n_samples_to_select), Reason.LIGHT_INFO_TRAINING)
        self.al_technique.update(self.dataset)




    '''
    def _select_next_samples(self, n_samples_to_select):
        x, y = self.dataset.get_unselected_data()
        #x, outputs, y, t_scores = self.al_technique.evaluate_samples(x, y, n_samples_to_select)
        x = self.al_technique.evaluate_samples(x, n_samples_to_select)
        # combining AL score with comparison of real output with calculated output
        quantity_classes = max(y) + 1
        scores = []
        #for i in range(len(x)):
            # ATTEMPT 1 78,5 con punta 80 - 73 con dopo - 58 solo
            #diff = torch.linalg.norm(torch.tensor(numpy.eye(quantity_classes)[y[i]]).to(support.device) - outputs[i].to(support.device))
            #scores.append(t_scores[i].item() + diff.item())

            # ATTEMPT 2 79 - 73 con dopo - 73 solo
            #ground_truth = torch.tensor(numpy.eye(quantity_classes)[y[i]]).to(support.device)
            # current_output = outputs[i]
            # max_val = torch.max(torch.cat([current_output[0:y[i]], current_output[y[i]+1:]]))
            # diff = current_output[y[i]] - max_val

            # ATTEMPT 3 78 - 70 con dopo - 64 solo
            # current_output = outputs[i]
            # diff = current_output[y[i]]

            # ATTEMPT 4 37 - 68 con dopo - 53 solo
            # current_output = outputs[i]
            # diff = 1 - current_output[y[i]]

            #scores.append(diff + t_scores[i].item())
            #scores.append(t_scores[i].item()) # 83 - 72 con dopo
            # scores.append(diff)

        # balancing the data by taking the same amount from each class
        def sort_by_float(current_tuple):
            return current_tuple[0]

        # combined_list = list(zip(scores, x, y))
        # combined_list = sorted(combined_list, key=sort_by_float, reverse=True)
        # scores, x, y = zip(*combined_list)

        # n_samples_to_select_for_each_class = int(n_samples_to_select/quantity_classes)
        # counters_for_classes = [0] * quantity_classes
        # selected_x = []
        # for i in range(len(x)):
        #     current_class = y[i]
        #     if counters_for_classes[current_class] < n_samples_to_select_for_each_class:
        #         counters_for_classes[current_class] += 1
        #         selected_x.append(x[i])
        self.dataset.annotate(x)
        clprint("Updating AL technique...".format(self.n_samples_to_select), Reason.LIGHT_INFO_TRAINING)
        self.al_technique.update(self.dataset)
'''