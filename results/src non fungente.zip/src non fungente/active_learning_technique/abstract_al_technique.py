

class AbstractALTechnique:

    def evaluate_samples(self, x, n_samples_to_select):
        pass

    def update(self, dataset):
        pass
